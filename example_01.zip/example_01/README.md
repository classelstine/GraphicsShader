# CS 184 Fall 2016
Instructor: James O'Brien

# USAGE
1. ‘cd’ into your assignment directory, type into the Terminal the following step by step
2. mkdir build
3. cd build
4. cmake ..
5. make

# Keyboard features
1. 'ESC': Exit
2. 'Q': Exit
3. 'F': Full screen
4. '↓': Translate objects down
5. '↑': Translate objects up
6. '←': Translate objects left
7. '→': Translate objects right
